var DOCUMENTATION_OPTIONS = {
    URL_ROOT: '',
    VERSION: 'v0.1',
    LANGUAGE: 'it',
    COLLAPSE_INDEX: false,
    FILE_SUFFIX: '.html',
    HAS_SOURCE: true,
    SOURCELINK_SUFFIX: '.txt'
};