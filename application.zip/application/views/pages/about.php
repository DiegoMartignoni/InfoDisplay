<h2>Sviluppatore - <strong>Diego Martignoni</strong></h2>
<div class="d-inline">
<h3> Pagine correlate: 
<a href="https://github.com/DiegoMartignoni" class="badge badge-primary">GitHub</a>
<a href="http://diegomartignoni.altervista.org/" class="badge badge-warning">Altervista</a>
</h3>
</div>
