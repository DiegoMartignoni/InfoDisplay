<h1>Informazioni</h1>
<h4>Questa web application è stata creata grazie ai <a href="https://www.youtube.com/playlist?list=PLillGF-RfqbaP_71rOyChhjeK1swokUIS" class="badge badge-success ml-1 mr-1">video</a> di Traversy Media</h4>
